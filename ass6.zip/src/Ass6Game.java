/**
 * ass6
 * name: bar balanga
 * ID: 322818543
 */

import Interfaces.LevelInformation;
import Levels.*;
import biuoop.GUI;

import java.util.ArrayList;
import java.util.List;

/**
 * class Ass6Game.
 */
public class Ass6Game {
    /**
     * main method that runs the game.
     *
     * @param args String.
     */
    public static void main(String[] args) {
        List<LevelInformation> list = new ArrayList<>();
        GUI gui = new GUI("bar", 800, 600);
        DirectHit directHit = new DirectHit();
        WideEazy wideEazy = new WideEazy();
        Green3 green3 = new Green3();
        FinalFour finalFour = new FinalFour();
        //goes over args array.
        for (int i = 0; i < args.length; i++) {
            //check which level should add to the list
            if (args[i].equals("1")) {
                list.add(directHit);
            } else if (args[i].equals("2")) {
                list.add(wideEazy);
            } else if (args[i].equals("3")) {
                list.add(green3);
            } else if (args[i].equals("4")) {
                list.add(finalFour);
            }
        }
        GameFlow gameFlow = new GameFlow();
        //run the level in the list order.
        gameFlow.runLevels(list);
    }
}
