package Shapes;
/**
 * ass5
 * name: bar balanga
 * ID: 322818543
 */
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * class Rectangle is for creating a Rectangle object.
 */
public class Rectangle {
    // fields
    private final double width;
    private final double height;
    private Point upperLeft;
    private Point upperRight;
    private Point downLeft;
    private Point downRight;
    private Color c;

    /**
     * contractor.
     * @param width of the rectangle .
     * @param height of the rectangle .
     * @param upperLeft point of the rectangle .
     */
    // Create a new rectangle with location and width/height.
    public Rectangle(Point upperLeft, double width, double height) {
        this.c = Color.black;
        this.height = height;
        this.width = width;
        this.upperLeft = upperLeft;
        double x = upperLeft.getX();
        double y = upperLeft.getY();
        this.downLeft = new Point(x, y + height);
        this.upperRight = new Point(x + width, y);
        this.downRight = new Point(x + width, y + height);
    }

    /**
     * @param line Line.
     *The function checks collision points with the entire list of lines
     * @return List of intersection points.
     */
    public List<Point> intersectionPoints(Line line) {
        List<Point> l = new ArrayList<Point>();
        double x = this.getUpperLeft().getX();
        double y = this.getUpperLeft().getY();
        Point p = new Point(x, y + getHeight());
        //Creates a line of the rectangle.
        Line l1 = new Line(getUpperLeft(), p);
        //Checks if there is a collision between the 2 lines and if so puts the collision point in the array.
        if (l1.intersectionWith(line) != null) {
            l.add(l1.intersectionWith(line));
        }
        p = new Point(x + getWidth(), y);
        //Creates a line of the rectangle.
        l1 = new Line(getUpperLeft(), p);
        //Checks if there is a collision between the 2 lines and if so puts the collision point in the array.
        if (l1.intersectionWith(line) != null) {
            l.add(l1.intersectionWith(line));
        }
        p = new Point(x + getWidth(), y + getHeight());
        Point p1 = new Point(x, y + getHeight());
        //Creates a line of the rectangle.
        l1 = new Line(p1, p);
        //Checks if there is a collision between the 2 lines and if so puts the collision point in the array.
        if (l1.intersectionWith(line) != null) {
            l.add(l1.intersectionWith(line));
        }
        p = new Point(x + getWidth(), y + getHeight());
        p1 = new Point(x + getWidth(), y);
        //Creates a line of the rectangle.
        l1 = new Line(p1, p);
        //Checks if there is a collision between the 2 lines and if so puts the collision point in the array.
        if (l1.intersectionWith(line) != null) {
            l.add(l1.intersectionWith(line));
        }
        return l;
    }

    /**
     * @param c color.
     * set the color.
     */
    public void setColor(Color c) {
        this.c = c;
    }

    /**
     * @return the width of the rectangle.
     */
    public double getWidth() {
        return this.width;
    }

    /**
     * @return the height of the rectangle.
     */
    public double getHeight() {
        return this.height;
    }

    /**
     * @return upper-left point.
     */
    public Point getUpperLeft() {
        return this.upperLeft;
    }

    /**
     * @return the upper-right point.
     */
    public Point getUpperRight() {
        return this.upperRight;
    }

    /**
     * @return the down-left point.
     */
    public Point getDownLeft() {
        return this.downLeft;
    }

    /**
     * @return the down-right point.
     */
    public Point getDownRight() {
        return this.downRight;
    }

    /**
     * @param p upper-left point.
     * @param step double.
     * set the rec.
     */
    public void setRec(Point p, double step) {
        this.upperLeft = new Point(p.getX() + step, p.getY());
        double x = upperLeft.getX();
        double y = upperLeft.getY();
        this.downLeft = new Point(x, y + height);
        this.upperRight = new Point(x + width, y);
        this.downRight = new Point(x + width, y + height);
    }

}





