package Shapes;
/**
 * ass5
 * name: bar balanga
 * ID: 322818543
 */

/**
 * class Point.
 */
public class Point {
    private double x;
    private double y;

    /**
     * costractor.
     * @param x double.
     * @param y double.
     */
    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    /**
     * @param  other Point.
     * @return return the distance of this point to the other point.
     */
    public double distance(Point other) {
        double dis = (this.x - other.getX()) * (this.x - other.getX())
                + (this.y - other.getY()) * (this.y - other.getY());
        dis = Math.sqrt(dis);
        return dis;
    }

    /**
     * @param other Point.
     * @return return true is the points are equal, false otherwise.
     */
    public boolean equals(Point other) {
        if ((this.x == other.getX()) && (this.y == other.getY())) {
            return true;
        }
            return false;
    }
    /**
     * @return x values of this point.
     */
    public double getX() {
        return x;
    }
    /**
     * @return y values of this point.
     */
    public double getY() {
        return y;
    }

    /**
     * @param x and chang the value of the x of the department.
     */
    public void setX(double x) {
        this.x = x;
    }
    /**
     * @param y and chang the value of the y of the department.
     */
    public void setY(double y) {
        this.y = y;
    }
}
