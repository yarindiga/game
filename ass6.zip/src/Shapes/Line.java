package Shapes;
/**
 * ass5
 * name: bar balanga
 * ID: 322818543
 */

/**
 * Class Line.
 */
public class Line {
    private final Point start;
    private final Point end;

    /**
     * @param start constructors action.
     * @param end
     */
    public Line(Point start, Point end) {
        this.start = start;
        this.end = end;
    }

    /**
     * @param x1 double.
     * @param y1 double.
     * @param x2 double.
     * @param y2 he action receives 4 double type points and creates a line with them.
     */
    public Line(double x1, double y1, double x2, double y2) {
        start = new Point(x1, y1);
        end = new Point(x2, y2);
    }

    /**
     * @return the length of the line.
     */
    public double length() {
        double len = (start.getX() - end.getX())
                * (start.getX() - end.getX()) + (start.getY() - end.getY()) * (start.getY() - end.getY());
        len = Math.sqrt(len);
        return len;
    }


    /**
     * @return the middle point of the line
     */
    public Point middle() {
        double x = (this.start.getX() + this.end.getX()) / 2;
        x = Math.abs(x);
        double y = (this.start.getY() + this.end.getY()) / 2;
        y = Math.abs(y);
        Point mid = new Point(x, y);
        return mid;
    }

    /**
     * @return the start point of the line.
     */
    public Point start() {
        return start;
    }

    /**
     * @return the end point of the line.
     */
    public Point end() {
        return end;
    }

    /**
     * @param l line.
     * @param p point.
     * @return true if there is intersection, false if not.
     */
    public boolean check(Line l, Point p) {
        double dis1, dis2, d1, d2;
        double min = 0.00000000001;
        dis1 = p.distance(this.start) + p.distance(this.end);
        d1 = this.start.distance(this.end);
        dis2 = p.distance(l.start) + p.distance(l.end);
        d2 = l.start.distance(l.end);
        //checks if the number is smaller them min, if true, the distance is equal and the point is on the line.
        return (Math.abs(dis1 - d1)) < min && (Math.abs(dis2 - d2) < min);
    }

    /**
     * @param other line.
     *              check if there is intersection between the lines.
     * @return true if there is intersection, false if not.
     */
    public boolean isIntersecting(Line other) {
        double m1, m2, b1, b2;
        double x, y;
        Point p;
        // m1 and m2 are the slope.
        m1 = (this.end.getY() - this.start.getY()) / (this.end.getX() - this.start.getX());
        b1 = this.start.getY() - (this.start.getX() * m1);
        m2 = (other.end.getY() - other.start.getY()) / (other.end.getX() - other.start.getX());
        b2 = other.start.getY() - (other.start.getX() * m2);
        // check if one of the lines are parallal to y.
        if ((this.start.getX() == this.end.getX()) && (other.start.getX() != other.end.getX())) {
            y = (m2 * this.start.getX()) + b2;
            p = new Point(this.start.getX(), y);
            return check(other, p);
        }
        // check if one of the lines are parallal to y.
        if (this.start.getX() != this.end.getX() && other.start.getX() == other.end.getX()) {
            y = (m1 * other.start.getX()) + b1;
            p = new Point(other.start.getX(), y);
            return check(other, p);
        }
        // check if both of the lines are parallal to y.
        if (this.start.getX() == this.end.getX() && other.start.getX() == other.end.getX()) {
            if (this.start.equals(other.start)) {
                return true;
            }
            if (this.start.equals(other.end)) {
                return true;
            }
            if (this.end.equals(other.start)) {
                return true;
            }
            return this.end.equals(other.end);
        }
        //check if lin the line are parallel and if they are return false.
        if (m1 == m2) {
            if (b1 != b2) {
                return false;
            }
            //check the line are the same.
            if (b1 == b2) {
                return this.check(other, other.start)
                        || this.check(other, other.end)
                        || other.check(this, this.start)
                        || other.check(this, this.end);
            }
        }
        //check the shared point.
        x = (b2 - b1) / (m1 - m2);
        y = (m1 * x) + b1;
        p = new Point(x, y);
        return check(other, p);
    }

    /**
     * @param other line.
     * @return point of the intersection.
     */
    public Point intersectionWith(Line other) {
        double x, y;
        double m1, m2, b1, b2;
        Point p;
        // check if there is a intersecting point
        if (this.isIntersecting(other)) {
            //check that the line arent equals.
            if (((this.start.getX() == this.end.getX()) && (this.start.getY() == this.end.getY()))
                    && ((other.start.getX() == other.end.getX()) && (other.start.getY() == other.end.getY()))) {
                return this.start;
            }
            // both line are perallal to y.
            if (this.start.getX() == this.end.getX() && other.start.getX() == other.end.getX()) {
                if (this.start.equals(other.start)) {
                    return this.start;
                }
                if (this.start.equals(other.end)) {
                    return this.start;
                }
                if (this.end.equals(other.end)) {
                    return this.end;
                }
                if (this.end.equals(other.start)) {
                    return this.end;
                }
                return null;
            }
            // m1 and m2 are the sloop.
            m1 = (this.end.getY() - this.start.getY()) / (this.end.getX() - this.start.getX());
            b1 = this.start.getY() - (this.start.getX() * m1);
            m2 = (other.end.getY() - other.start.getY()) / (other.end.getX() - other.start.getX());
            b2 = other.start.getY() - (other.start.getX() * m2);
            x = (b2 - b1) / (m1 - m2);
            y = (m1 * x) + b1;
            // one perallal to y.
            if (this.start.getX() == this.end.getX() && other.start.getX() != other.end.getX()) {
                x = this.start.getX();
                y = (m2 * x) + b2;
                p = new Point(x, y);
                return p;
            }
            //one parellal to y.
            if (this.start.getX() != this.end.getX() && other.start.getX() == other.end.getX()) {
                x = other.start.getX();
                y = (m1 * x) + b1;
                p = new Point(x, y);
                return p;

            }
            //if both lines has the same the point can be only at the start or the end.
            if (m1 == m2 && b1 == b2) {
                if (this.start.equals(other.start)) {
                    return this.start;
                }
                if (this.start.equals(other.end)) {
                    return this.start;
                }
                if (this.end.equals(other.end)) {
                    return this.end;
                }
                if (this.end.equals(other.start)) {
                    return this.end;
                }
                return null;
            }
            p = new Point(x, y);
            return p;
        }
        return null;
    }

    /**
     * @param other line
     * @return true is the lines are equal, false otherwise
     */
    public boolean equals(Line other) {
        //Equation between the X points of the lines and the Y points of the lines
        return ((other.start.getX() == this.start.getX()) && (other.start.getY() == this.start.getY()))
                && ((other.end.getX() == this.end.getX()) && (other.end.getY() == this.end.getY()));
    }

    /**
     * @param rect Rectangle.
     * @return the point that closest Intersection To Start Of Line.
     */
    public Point closestIntersectionToStartOfLine(Rectangle rect) {
        double x = rect.getUpperLeft().getX();
        double y = rect.getUpperLeft().getY();
        Point[] arr = new Point[4];
        int count = 0, c = 0;
        double min;
        Point p1;
        Point p = new Point(x + rect.getWidth(), y);
        //creat line.
        Line l = new Line(rect.getUpperLeft(), p);
        //check if there is intersetion.
        if (intersectionWith(l) != null) {
            arr[count] = intersectionWith(l);
            count++;
        }
        p = new Point(x, y + rect.getHeight());
        //creat line.
        l = new Line(rect.getUpperLeft(), p);
        //check if there is intersetion.
        if (intersectionWith(l) != null) {
            arr[count] = intersectionWith(l);
            count++;
        }
        p = new Point(x, y + rect.getHeight());
        p1 = new Point(x + rect.getWidth(), y + rect.getHeight());
        //creat line.
        l = new Line(p1, p);
        //check if there is intersetion.
        if (intersectionWith(l) != null) {
            arr[count] = intersectionWith(l);
            count++;
        }
        p = new Point(x + rect.getWidth(), y);
        p1 = new Point(x + rect.getWidth(), y + rect.getHeight());
        //creat line.
        l = new Line(p1, p);
        //check if there is intersetion.
        if (intersectionWith(l) != null) {
            arr[count] = intersectionWith(l);
            count++;
        }
        // if there is no intersetion return null.
        if (count == 0) {
            return null;
        } else {
            min = start.distance(arr[0]);
            //for to finf the min in the array.
            for (int i = 1; i < count; i++) {
                if (start.distance(arr[i]) < min) {
                    min = start.distance(arr[i]);
                    c = i;
                }
            }
        }
        return arr[c];
    }

}


