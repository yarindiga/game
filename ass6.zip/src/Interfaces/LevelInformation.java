package Interfaces;

import Collidables.Sprite;
import Collidables.Velocity;
import ShownObject.Block;
import java.util.List;

/**
 * interface LevelInformation.
 */
public interface LevelInformation {
    /**
     * @return int number Of Balls.
     */
    int numberOfBalls();
    /**
     * @return The initial velocity of each ball
     */
    List<Velocity> initialBallVelocities();

    /**
     * @return paddle Speed.
     */
    int paddleSpeed();

    /**
     * @return paddle Width.
     */
    int paddleWidth();
    /**
     * @return the level name and it  will be displayed at the top of the screen.
     */
    String levelName();

    /**
     * @return a sprite with the background of the level.
     */
    Sprite getBackground();

    /**
     * @return The Blocks that make up this level, each block contains its size, color and location.
     */
    List<Block> blocks();
    /**
     * @return Number of blocks that should be removed.
     */
    int numberOfBlocksToRemove();


}
