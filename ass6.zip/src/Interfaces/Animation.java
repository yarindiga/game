package Interfaces;
import biuoop.DrawSurface;

/**
 * interface Animation.
 */
public interface Animation {
    /**
     * @param d DrawSurface.
     * drew the animation.
     */
    void doOneFrame(DrawSurface d);

    /**
     * @return true to stop and false to continue.
     */
    boolean shouldStop();
}
