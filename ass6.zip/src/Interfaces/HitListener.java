/**
 * ass5
 * name: bar balanga
 * ID: 322818543
 */
package Interfaces;
import ShownObject.Ball;
import ShownObject.Block;

/**
 * interface HitListener.
 */
public interface HitListener {
    /**
     * @param beingHit block.
     * @param hitter ball.
     * his method is called whenever the beingHit object is hit.
     * The hitter parameter is the Ball that's doing the hitting.
     */
    void hitEvent(Block beingHit, Ball hitter);
}