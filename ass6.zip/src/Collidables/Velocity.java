package Collidables;
import Shapes.*;
import ShownObject.*;
public class Velocity {
    private double dx;
    private double dy;

    /**
     * @param dx double.
     * @param dy double.
     * constructor.
     */

    public Velocity(double dx, double dy) {
        this.dx = dx;
        this.dy = dy;
    }

    /**
     * @param p point
     *  Take a point (x,y) and return a new point (x+dx, y+dy).
     * @return new point
     */
    public Point applyToPoint(Point p) {
        double x = p.getX() + this.getDx();
        double y = p.getY() + this.getDy();
        Point P = new Point(x, y);
        return P;
    }
    /**
     * @return dx double.
*/
    public double getDx() {
        return this.dx;
    }

    /**
     * @return dy double.
*/
    public double getDy() {
        return dy;
    }

    /**
     * @param x double.
     * set the value of the x.
*/
    public void setDx(double x) {
        this.dx = x;
    }


    /**
     * @param y double.
     * set the value of y.
*/
    public void setDy(double y) {
        this.dy = y;
    }

    /**
     * @param angle double.
     * @param speed double.
     * @return Velocity from speed and angle.
*/
    public static Velocity fromAngleAndSpeed(double angle, double speed) {
       double dx =  speed * Math.sin(Math.toRadians(angle));
        double dy =  (-1) * speed *  Math.cos(Math.toRadians(angle));
        return new Velocity(dx, dy);
    }
}

