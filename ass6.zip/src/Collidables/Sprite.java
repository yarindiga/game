package Collidables;
/**
 * ass3
 * name: bar balanga
 * ID: 322818543
 */
import biuoop.DrawSurface;
import Shapes.*;
import ShownObject.*;
public interface Sprite {
    // draw the sprite to the screen
    void drawOn(DrawSurface d);

    // notify the sprite that time has passed
    void timePassed();
}