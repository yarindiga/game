package Collidables;
/**
 * class CollisionInfo.
 */
import Shapes.*;
import ShownObject.*;
public class CollisionInfo {
    private Point point;
    private Collidable collidable;

    /**
     * constractor.
     * @param point Point.
     * @param collidable Collidable.
     */
    public CollisionInfo(Point point, Collidable collidable) {
        this.point = point;
        this.collidable = collidable;
    }

    /**
     * @return point.
     */
    public Point collisionPoint() {
        return this.point;
    }

    /**
     * @return collidable.
     */
    public Collidable collisionObject() {
        return this.collidable;
    }
}