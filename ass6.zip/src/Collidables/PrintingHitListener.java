/**
 * ass5
 * name: bar balanga
 * ID: 322818543
 */
package Collidables;
import Interfaces.HitListener;
import ShownObject.Ball;
import ShownObject.Block;

/**
 * class PrintingHitListener.
 */
public class PrintingHitListener implements HitListener {
    /**
     * @param beingHit block.
     * @param hitter ball.
     * his method is called whenever the beingHit object is hit.
     */
    public void hitEvent(Block beingHit, Ball hitter) {
        System.out.println("A Block was hit.");
    }
}