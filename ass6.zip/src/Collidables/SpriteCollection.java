package Collidables;
/**
 * ass3
 * name: bar balanga
 * ID: 322818543
 */

import biuoop.DrawSurface;
import java.util.ArrayList;
import java.util.List;
import Shapes.*;
import ShownObject.*;
public class SpriteCollection {
    private List<Sprite> list;

    //constructor
    public SpriteCollection() {
        this.list = new ArrayList<>();
    }

    /**
     * add spirit to Sprite list.
     * @param s Sprite.
     */
    public void notifyAllTimePassed(Sprite s) {
        this.list.add(s);
    }

    /**
     * timePassed() on all the list.
     */
    public void timePassed() {
        for (int i = 0; i < list.size(); i++) {
            this.list.get(i).timePassed();
        }
    }

    /**
     * drawOn on all the list.
     * @param d surface.
     */
    public void drawAllOn(DrawSurface d) {
        for (int i = 0; i < list.size(); i++) {
            this.list.get(i).drawOn(d);
        }
    }
    public void removeSpirte(Sprite s){
        list.remove(s);
    }
}