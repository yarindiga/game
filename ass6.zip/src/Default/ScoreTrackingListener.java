/**
 * ass6
 * name: bar balanga
 * ID: 322818543
 */
package Default;

import Interfaces.HitListener;
import ShownObject.Ball;
import ShownObject.Block;

/**
 * class ScoreTrackingListener.
 */
public class ScoreTrackingListener implements HitListener {
    private Counter currentScore;

    /**
     * @param scoreCounter counter.
     * constructor.
     */
    public ScoreTrackingListener(Counter scoreCounter) {
        this.currentScore = scoreCounter;
    }

    /**
     * @param beingHit block.
     * @param hitter ball.
     * at the hit, the score increases in 5 point.
     */
    public void hitEvent(Block beingHit, Ball hitter) {
        this.currentScore.increase(5);
    }
}