/**
 * ass3
 * name: bar balanga
 * ID: 322818543
 */
package Default;
import Collidables.GameLevel;
import Interfaces.HitListener;
import ShownObject.Ball;
import ShownObject.Block;
import java.awt.*;
/**
 * class blockWhite.
 */
public class BlockWhite implements HitListener {
    private GameLevel game;

    /**
     * @param game Game.
     * constructor.
     */
    public BlockWhite(GameLevel game) {
        this.game = game;
    }

    /**
     * @param beingHit Block.
     * @param hitter Ball.
     * at the hit the boll change his color from black to white.
     */
    @Override
    public void hitEvent(Block beingHit, Ball hitter) {
        hitter.setColor(Color.WHITE);
        hitter.setVelocity(30, -2);
    }
}
