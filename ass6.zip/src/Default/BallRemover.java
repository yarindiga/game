/**
 * ass6
 * name: bar balanga
 * ID: 322818543
 */
package Default;
import Collidables.GameLevel;
import Interfaces.HitListener;
import ShownObject.Ball;
import ShownObject.Block;

/**
 * class BallRemover.
 */
public class BallRemover implements HitListener {
    private GameLevel game;
    private Counter remainingBall;

    /**
     * @param game game.
     * @param removedBall counter.
     * constructor.
     */
    public BallRemover(GameLevel game, Counter removedBall) {
        this.game = game;
        this.remainingBall = removedBall;
    }

    /**
     * @param beingHit block.
     * @param hitter ball.
     * his method is called whenever the beingHit object is hit.
     * Blocks that are hit should be removed from the game.
     * Remember to remove this listener from the block that is being removed from the game.
     */
    public void hitEvent(Block beingHit, Ball hitter) {
        hitter.removeHitListener(this);
        hitter.removeFromGame(this.game);
        this.remainingBall.decrease(1);
    }
}
