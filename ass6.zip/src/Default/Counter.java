/**
 * ass3
 * name: bar balanga
 * ID: 322818543
 */
package Default;

/**
 * class Counter.
 */
public class Counter {
    private int counter;

    /**
     * @param c int.
     *          constructor.
     */
    public Counter(int c) {
        this.counter = c;
    }

    /**
     * @param number int.
     * add number to current count.
     */
    public void increase(int number) {
        this.counter += number;
    }
    /**
     * @param number int.
     * subtract number from current count.
     */
    public void decrease(int number) {
        this.counter -= number;
    }

    /**
     * get current count.
     * @return counter int.
     */
    public int getValue() {
        return counter;
    }
}