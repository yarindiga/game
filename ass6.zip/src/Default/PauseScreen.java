package Default;

import Interfaces.Animation;
import biuoop.DrawSurface;
import biuoop.KeyboardSensor;

/**
 * PauseScreen implements Animation.
 */
public class PauseScreen implements Animation {
    private KeyboardSensor keyboard;
    private boolean stop;

    /**
     * @param k KeyboardSensor.
     *  constructor.
     */
    public PauseScreen(KeyboardSensor k) {
        this.keyboard = k;
        this.stop = false;
    }
    @Override
    public void doOneFrame(DrawSurface d) {
        //drew the text.
        d.drawText(10, d.getHeight() / 2, "paused -- press space to continue", 32);
        //if we press space the animation stop.
        //if (this.keyboard.isPressed(KeyboardSensor.SPACE_KEY)) {
       //     this.stop = true;
       // }
    }

    /**
     * @return true to stop and false to continue.
     */
    @Override
    public boolean shouldStop() {
        return this.stop; }
}
