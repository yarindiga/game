package Levels;

import Default.Counter;
import Interfaces.Animation;
import biuoop.DrawSurface;
import biuoop.KeyboardSensor;

import java.awt.*;

/**
 * class GameOver implements Animation.
 */
public class GameOver implements Animation {
    private final KeyboardSensor keyboard;
    private boolean stop;
    private final Counter score;

    /**
     * @param k KeyboardSensor.
     * @param score Counter.
     * constuctor.
     */
    public GameOver(KeyboardSensor k, Counter score) {
        this.keyboard = k;
        this.stop = false;
        this.score = score;
    }
    /**
     * draw the animation.
     */
    @Override
    public void doOneFrame(DrawSurface d) {
        d.setColor(Color.gray);
        d.fillRectangle(0, 0, 800, 600);
        d.setColor(Color.pink);
        d.drawText(50, d.getHeight() / 2, "Game Over! your score is: " + this.score.getValue(), 40);
      //  if (this.keyboard.isPressed(KeyboardSensor.SPACE_KEY)) {
      //      this.stop = true;
        //}
    }
    /**
     * @return Number of blocks that should be removed.
     */
    @Override
    public boolean shouldStop() {
        return this.stop;
    }
}