import java.io.*;
import java.util.Comparator;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * class DiscoverHypernym.
 */
public class DiscoverHypernym {
    /**
     * Static Method with return type Map and extending comparator class which compares values
     * associated with two keys.
     * @param map Map.
     * @param <K> value.
     * @param <V> value.
     * @return Sorted map.
     */
    public static <K, V extends Comparable<V>> Map<K, V>
    valueSort(TreeMap<K, V> map) {
        Comparator<K> valueComparator = new Comparator<K>() {

            public int compare(K k1, K k2) {

                int comp = map.get(k1).compareTo(map.get(k2));

                if (comp == 0) {
                    return 1;
                } else {
                    return -comp;
                }
            }
        };
        TreeMap<K, V> sort = new TreeMap<K, V>(valueComparator);
        sort.putAll(map);
        return sort;
    }

    /**
     * @param args string array.
     * in the main we build the data base.
     */
    public static void main(String[] args) {
        String s1;
        String s2;
        try {
            s1 = args[0];
            s2 = args[1];
        } catch (RuntimeException e) {
            throw new RuntimeException("Missing path");
        }
        BufferedReader is = null;
        TreeMap<String, TreeMap<String, Integer>> m = new TreeMap<String, TreeMap<String, Integer>>();
        Pattern[] patterns = new Pattern[5];
        //create patterns.
        patterns[0] = Pattern.compile("<np>([^>]+)</np> ?,? such as <np>([^>]+)</np> (?: ?,?"
                + "<np>([^>]+)</np>)*(?: ?,? (?:and|or) <np>([^>]+)</np>)?");
        patterns[1] = Pattern.compile("such <np>([^>]+)</np> ?,? as <np>([^>]+)</np> (?: ?,?"
                + "<np>([^>]+)</np>)*(?: ?,? (?:and|or) <np>([^>]+)</np>)?");
        patterns[2] = Pattern.compile("<np>([^>]+)</np> ?,? including <np>([^>]+)</np> (?: ?,?"
                + "<np>([^>]+)</np>)*(?: ?,? (?:and|or) <np>([^>]+)</np>" + ")?");
        patterns[3] = Pattern.compile("<np>([^>]+)</np> ?,? especially <np>([^>]+)</np> (?: ?,?"
                + "<np>([^>]+)</np>)*(?: ?,? (?:and|or) <np>([^>]+)</np>" + ")?");
        patterns[4] = Pattern.compile("<np>([^>]+)</np>,?( )?(,)? which is "
                + "(?:(?:an example|a kind|a class) of)? <np>([^>]+)</np>");
        try {
            //goes over all the files.
            for (int k = 0; k < 84; k++) {
                is = new BufferedReader(// wrapper that reads ahead
                        new InputStreamReader(// wrapper that reads characters
                                new FileInputStream(args[0] + "\\mbta.com_mtu.pages_" + k + ".possf2")));
                String line;
                Matcher matcher;
                //null means no more data in the stream.
                while ((line = is.readLine()) != null) {
                    //goes over all the five pattern and looking for a match.
                    for (int i = 0; i < 5; i++) {
                        matcher = patterns[i].matcher(line);
                        //finding a match.
                        while (matcher.find()) {
                            //check which pattern.
                            if (i != 4) {
                                String s = matcher.group(1).toLowerCase(Locale.ROOT);
                                //check if there is the same key already.
                                if (m.containsKey(s)) {
                                    for (int j = 2; j < matcher.groupCount(); j++) {
                                        if (matcher.group(j) != null) {
                                    //chack if there is the same group and add there integer or if there not add new.
                                            if (m.get(s).containsKey(matcher.group(j).toLowerCase(Locale.ROOT))) {
                                                int num = m.get(s).get(matcher.group(j).toLowerCase(Locale.ROOT));
                                                num++;
                                                m.get(s).replace(matcher.group(j).toLowerCase(Locale.ROOT), num);
                                            } else {
                                                m.get(s).put(matcher.group(j).toLowerCase(Locale.ROOT), 1);
                                            }
                                        }
                                    }
                                } else {
                                    //if there isnt the same key, we put the key in the map.
                                    m.put(s, new TreeMap<String, Integer>());
                                    //we put all his groups too.
                                    for (int j = 2; j < matcher.groupCount(); j++) {
                                        if (matcher.group(j) != null) {
                                            m.get(s).put(matcher.group(j).toLowerCase(Locale.ROOT), 1);
                                        }
                                    }
                                }
                            } else {
                                //if this is the 5 pattern.
                                String s = matcher.group(matcher.groupCount() - 1);
                                if (s != null) {
                                    //check if there is the same key already.
                                    if (m.containsKey(s)) {
                                        if (matcher.group(1) != null) {
                                            if (m.get(s).containsKey(matcher.group(1))) {
                                                int num = m.get(s).get(matcher.group(1));
                                                num++;
                                                m.get(s).replace(matcher.group(1), num);
                                            } else {
                                                m.get(s).put(matcher.group(1), 1);
                                            }
                                        }
                                    } else {
                                        //if there isnt the same key, we put the key in the map.
                                        m.put(s, new TreeMap<String, Integer>());
                                    }
                                    if (matcher.group(1) != null) {
                                        m.get(s).put(matcher.group(1), 1);
                                    }
                                }

                            }
                        }
                    }

                }
            }
            TreeMap<String, Integer> map = new TreeMap<>();
            //for that goes over all the main key.
            for (String key : m.keySet()) {
                //for that goes over all the inter key.
                for (String st : m.get(key).keySet()) {
                    //check if the lemma is eguals to the key.
                    if (st.equals(s2)) {
                        map.put(key, m.get(key).get(st));
                    }
                }
            }
            //sorted the map and print it.
            Map<String, Integer> sorted = valueSort(map);
            for (String key : sorted.keySet()) {
                System.out.println(key + ": (" + map.get(key) + ")");
            }
        } catch (IOException e) {
            System.out.println(" Something went wrong while reading !");
        } finally {
            if (is != null) { // Exception might have happened at constructor
                try {
                    is.close(); // closes FileInputStream too
                } catch (IOException e) {
                    System.out.println(" Failed closing the file !");
                }
            }
        }

    }
}
